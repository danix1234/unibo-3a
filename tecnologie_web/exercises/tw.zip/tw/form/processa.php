<?php
    echo "Get: ".$_GET["supereroe"]."<br />";
    echo "Post: ".$_POST["supereroe"]."<br />";
    echo "Request: ".$_REQUEST["supereroe"]."<br />";
?>