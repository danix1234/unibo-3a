<?php
setcookie("username", "", time() - 3600,  '/');


?>