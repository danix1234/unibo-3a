<?php
$a = array(1, array("a", "b", "c"));
var_dump($a);
?>
